package Alura.ExOObjetos;

public class Main {
    public static void main(String[] args) {
    Conta C1 = new Conta ("Laura", "1020", 1122, 2000, new Data(1,10,2024));

    Conta C2 = new Conta ("Caio", "1020", 4355, 5230, new Data(24, 2, 2019));

        C1.recuperaDadosImpressao();
        C2.recuperaDadosImpressao();

        if (C1 == C2){
            System.out.println("Contas iguais");
        } else{
            System.out.println("Contas diferentes");
        }

        C1.checarSaldo();
        C1.depositar(500);
        C1.sacar(200);
        C1.calculoRendimento();
        C1.checarSaldo();


    }
}
