package Alura.ExOObjetos;

public class Conta {
    String titular;
    String agencia;
    int numero;
    private double saldo;
    Data dataAbertura;

    public Conta (String titular, String agencia, int numero, double saldo, Data dataAbertura) {
        this.titular = titular;
        this.agencia = agencia;
        this.numero = numero;
        this.saldo = saldo;
        this.dataAbertura = dataAbertura;
    }
    public void recuperaDadosImpressao() {
        System.out.printf("""
                ======================================
                TITULAR =  %s
                AGÊNCIA = %s
                NÚMERO = %d
                SALDO = %.2f
                DATA DE ABERTURA = %s
                ======================================
                """, titular, agencia, numero, saldo, dataAbertura.toString());


    }
    public void checarSaldo () {
        System.out.println("Saldo atual: " + saldo);
    }
    public void depositar(double valor) {
        this.saldo += valor;
        System.out.println("Você depositou " + valor);
        System.out.println("Saldo atual: " + this.saldo);

    }
    public void sacar(double valor) {
        if (this.saldo >= valor) {
            this.saldo -= valor;
            System.out.println("Você sacou " + valor);
            System.out.println("Saldo atual: " + this.saldo);
        }else{
            System.out.println("Saldo insuficiente");
        }
    }
    public void calculoRendimento() {
        double rendimento = this.saldo * 0.1;
        this.saldo = this.saldo + rendimento;
        System.out.println("Seu rendimento de 10% é de: " + rendimento);
        System.out.println("Seu saldo com rendimento é de: " + this.saldo);
    }
}
